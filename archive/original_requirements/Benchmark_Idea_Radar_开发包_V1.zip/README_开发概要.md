# Benchmark Idea Radar 开发需求包 V1

## 产品目标
为金融、法律、医疗、科研、Agent 等垂类持续发现高价值 Benchmark Idea。
最终产物不是 AI 新闻摘要，而是可评测、可验证、可立项的 Benchmark Idea。

核心链路：
`发现信号 → 抽象能力 → Evaluation Gap → Idea → 自动评分 → Mini Eval → 正式立项`

## 四条 Radar
1. Benchmark / Leaderboard：别人正在测什么？→ Evaluation Gap
2. Expert Workflow：专业人士真实在做什么？→ Real-world Task
3. Product / Agent：AI 现在开始能做什么？→ New Capability
4. Model Failure：当前模型到底做不好什么？→ Failure Pattern

Radar Hits：1=观察；2=候选；3=优先 Mini Eval；4=重点立项候选。

## 数据流
SourceItem → ExtractedSignal → IdeaCard → MiniEval → BenchmarkProject

## Idea Card Schema
- idea_name
- domain
- sources[]
- source_refs[]
- real_world_task
- capability
- input
- expected_output
- why_hard
- expected_failure
- existing_benchmark
- evaluation_gap
- evaluation_method
- data_source
- mvp_plan
- radar_hits
- status

## 自动评分（100）
- Real-world Value 20
- Model Weakness 20
- Model Differentiation 15
- Novelty 15
- Evaluability 15
- Data Feasibility 10
- Expert Cost 5

建议阈值：80+ 优先 Mini Eval；65-79 候选；50-64 观察；<50 暂缓。

## Scout
### Benchmark Scout
监控论文、HF、GitHub、Leaderboard、研究机构。抽取 Benchmark、能力、任务、Metric、SOTA/模型表现、Failure、创新点、Gap、衍生 Idea。

### Workflow Scout
研究专业人士真实任务。抽取 Profession、Task、Input、Workflow、Output、Required Expertise、Hardest Step、Common Human Mistakes、Likely LLM Failures、Benchmark Potential。

### Product Scout
监控产品更新，但把产品功能转换成 Capability / Real-world Task / Potential Failure / Evaluation Opportunity / Benchmark Idea。

### Failure Scout
从 Bad Case、内部评测、竞品对比抽取可泛化 Failure Pattern，判断是否值得形成 Benchmark。

### Idea Analyst
去重 → 聚类 → 能力抽象 → Gap Analysis → Idea Card → Radar Hits → 评分 → Weekly Top 10。

## Weekly Output
- Top 10 Idea
- Top 3：马上 Mini Eval
- Top 3：持续观察
- Top 3：热门但不建议做
- Idea 的新增/升档/降档/淘汰变化

## Mini Eval Gate
每个高优先级 Idea 先做 30-50 题，多模型实测。
正式立项要求：
- 真实价值明确
- Failure 可复现
- 模型有区分度
- Reference/Rubric 可稳定评判
- 数据和专家成本可接受

## V1 开发优先级
P0：
- 四类 Source 配置 + 定时采集
- 解析 / 去重 / 结构化抽取
- Idea Card + Idea Analyst
- 自动评分 + Radar Hits + 状态流转

P1：
- Weekly Top 10 报告
- Mini Eval 结果回流
- 搜索 / 标签 / 版本历史

P2：
- 自动生成 Mini Eval 草案
- Dashboard / 趋势分析

## 验收
- 四条 Radar 可周期运行
- 跨来源去重/聚类
- 自动生成完整 Idea Card
- 自动评分可解释且可人工覆盖
- Weekly Top 10 可直接用于 PM 决策
- Idea 可追溯原始来源
- Mini Eval 可回流更新评分
